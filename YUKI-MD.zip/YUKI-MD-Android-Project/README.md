# YUKI-MD Android + WhatsApp bot

Le ZIP contient `android-app` (projet Android Studio Kotlin) et `bot-backend` (Node.js pour Render).

## Backend Render
1. Déploie le contenu de `bot-backend` comme service Node.js/Blueprint.
2. Variables Render : `OWNER_NUMBER` (numéro international, chiffres seulement), `API_KEY` (secret long), `AUTH_DIR=/data/auth_info`.
3. Le disque persistant `/data` est nécessaire pour garder la session WhatsApp et dépend d'un forfait Render compatible.
4. Scanne le QR dans les logs avec WhatsApp > Appareils connectés.

## Application Android
Ouvre `android-app` dans Android Studio, synchronise Gradle et lance sur ton téléphone. Pour créer l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s).

Dans l'application, saisis l'URL HTTPS Render et la valeur `API_KEY`. L'app affiche l'état, l'uptime et les derniers messages, et envoie un texte/une commande WhatsApp au numéro `OWNER_NUMBER`.

L'historique des messages est temporaire (mémoire serveur). Ce n'est pas l'application officielle WhatsApp. Ne partage jamais l'API_KEY, le QR ou les fichiers de session. Les commandes `.play` et `.video` ne sont pas incluses. Baileys est une bibliothèque non officielle et WhatsApp peut modifier son fonctionnement.

## Icône et création de l'APK
L'image fournie a été ajoutée comme icône de l'application YUKI-MD.
Pour générer automatiquement l'APK sans Android Studio :
1. Décompresse ce ZIP puis envoie le dossier du projet dans un dépôt GitHub.
2. Ouvre l'onglet **Actions** du dépôt et lance **Build YUKI-MD APK** (ou attends la fin du lancement automatique après l'envoi des fichiers).
3. Quand l'exécution est terminée, ouvre-la puis télécharge l'élément **YUKI-MD-APK** dans la section **Artifacts**.
4. Décompresse l'élément téléchargé et ouvre `app-debug.apk` sur ton téléphone pour l'installer.
L'APK est une version de test Android (debug). Android peut demander d'autoriser l'installation de cette source.
