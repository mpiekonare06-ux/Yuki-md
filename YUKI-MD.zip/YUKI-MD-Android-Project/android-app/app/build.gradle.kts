plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.yukimd.app"; compileSdk=35
 defaultConfig { applicationId="com.yukimd.app"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" } }
