package com.yukimd.app
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType
import org.json.JSONObject
import org.json.JSONArray
import java.net.URL
import java.net.HttpURLConnection
import kotlin.concurrent.thread

class MainActivity:Activity(){
 private val bg=Color.rgb(15,12,25); private val panel=Color.rgb(34,27,49); private val gold=Color.rgb(235,190,105); private val white=Color.WHITE
 private lateinit var url:EditText; private lateinit var key:EditText; private lateinit var state:TextView; private lateinit var uptime:TextView; private lateinit var log:TextView; private lateinit var message:EditText
 private val prefs by lazy{getSharedPreferences("yuki",MODE_PRIVATE)}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val scroll=ScrollView(this);val root=LinearLayout(this).apply{orientation=1;setPadding(22,24,22,28);setBackgroundColor(bg)};scroll.addView(root);setContentView(scroll)
 text(root,"👑  Y U K I - M D",27f,gold,true,Gravity.CENTER);text(root,"CENTRE DE CONTRÔLE • V1.0",12f,gold,true,Gravity.CENTER)
 val c=card(root,"⚙️ Connexion Render");url=edit("URL HTTPS Render",prefs.getString("url","")!!);key=edit("API_KEY",prefs.getString("key","")!!,true);c.addView(url);c.addView(key);button(c,"Enregistrer",gold){save();toast("Configuration enregistrée")}
 val d=card(root,"📊 Tableau de bord");state=text(d,"État : non vérifié",18f,white,true);uptime=text(d,"Uptime : —",14f,white);button(d,"Actualiser le statut",gold){status()}
 val chat=card(root,"💬 Discussion WhatsApp");text(chat,"Les messages sont envoyés au numéro propriétaire configuré sur Render.",12f,0xffc9c2d2.toInt());log=text(chat,"Aucun message chargé.",14f,white);message=edit("Message ou commande, ex. .menu");chat.addView(message);button(chat,"Envoyer sur WhatsApp",gold){send()};button(chat,"Actualiser les messages",0xff8d78ad.toInt()){messages()}
 text(root,"YUKI-MD • Ne partage jamais ta clé API ni ton QR.",11f,0xffaaa3b5.toInt())
 }
 private fun card(parent:LinearLayout,title:String):LinearLayout{val x=LinearLayout(this).apply{orientation=1;setPadding(15,12,15,15);setBackgroundColor(panel)};parent.addView(x,Linear(-1,-2).apply{topMargin=17});text(x,title,18f,gold,true);return x}
 private fun text(p:LinearLayout,s:String,size:Float,color:Int,bold:Boolean=false,gravity:Int=Gravity.START):TextView{val t=TextView(this).apply{text=s;textSize=size;setTextColor(color);this.gravity=gravity;if(bold)setTypeface(null,1);setPadding(0,7,0,9)};p.addView(t,Linear(-1,-2));return t}
 private fun edit(h:String,v:String="",secret:Boolean=false):EditText=EditText(this).apply{hint=h;setText(v);setTextColor(white);setHintTextColor(0xffaaa3b5.toInt());if(secret)inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
 private fun button(p:LinearLayout,s:String,color:Int,fn:()->Unit){p.addView(Button(this).apply{text=s;setTextColor(Color.BLACK);setBackgroundColor(color);setOnClickListener{fn()}},Linear(-1,-2).apply{topMargin=6})}
 private fun Linear(w:Int,h:Int)=LinearLayout.LayoutParams(w,h)
 private fun save(){prefs.edit().putString("url",url.text.toString().trim().trimEnd('/')).putString("key",key.text.toString().trim()).apply()}
 private fun config():Pair<String,String>?{save();val u=url.text.toString().trim().trimEnd('/');val k=key.text.toString().trim();if(!u.startsWith("https://")||k.isBlank()){toast("Entre l’URL HTTPS et la clé API.");return null};return Pair(u,k)}
 private fun api(path:String,method:String="GET",body:JSONObject?=null,done:(Int,String)->Unit){val cfg=config()?:return;thread{var code=-1;var out="";try{val c=URL(cfg.first+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=12000;c.readTimeout=12000;c.setRequestProperty("Authorization","Bearer "+cfg.second);c.setRequestProperty("Content-Type","application/json");if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toString().toByteArray())}};code=c.responseCode;out=(if(code in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()}?:"";c.disconnect()}catch(e:Exception){out=e.message?:"Erreur réseau"};runOnUiThread{done(code,out)}}}
 private fun status(){api("/api/status"){code,s->if(code==200){val j=JSONObject(s);state.text=if(j.optBoolean("connected"))"État : 🟢 EN LIGNE" else "État : 🔴 HORS LIGNE";val n=j.optLong("uptimeSeconds");uptime.text="Uptime : ${n/3600}h ${(n%3600)/60}m ${n%60}s"}else{state.text="État : erreur HTTP $code";toast(s.take(150))}}}
 private fun send(){val s=message.text.toString().trim();if(s.isEmpty()){toast("Écris un message.");return};api("/api/send","POST",JSONObject().put("text",s)){code,out->if(code==200){message.setText("");toast("Message envoyé.");messages()}else toast("Échec : "+out.take(140))}}
 private fun messages(){api("/api/messages"){code,s->if(code==200){val a=JSONObject(s).optJSONArray("messages")?:JSONArray();val b=StringBuilder();for(i in 0 until a.length()){val m=a.getJSONObject(i);b.append(if(m.optString("direction")=="out")"MOI → BOT" else "BOT → MOI").append(": ").append(m.optString("text")).append("\n\n")};log.text=if(b.isEmpty())"Aucun message reçu." else b.toString()}else toast("Erreur de chargement HTTP $code")}}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
