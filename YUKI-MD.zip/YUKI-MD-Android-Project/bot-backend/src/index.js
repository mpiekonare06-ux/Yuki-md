const express=require('express'),pino=require('pino'),qr=require('qrcode-terminal'),crypto=require('crypto');
const {default:makeWASocket,useMultiFileAuthState,DisconnectReason,fetchLatestBaileysVersion}=require('@whiskeysockets/baileys');
const fs=require('fs');
const PORT=process.env.PORT||3000, OWNER=(process.env.OWNER_NUMBER||'').replace(/\D/g,''), KEY=process.env.API_KEY||'', AUTH=process.env.AUTH_DIR||'/data/auth_info';
const app=express(); app.use(express.json({limit:'20kb'}));
let sock=null,connected=false; const messages=[];
function auth(req,res,next){const t=(req.get('authorization')||'').replace(/^Bearer\s+/i,'');const a=Buffer.from(t),b=Buffer.from(KEY);if(!KEY||a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(401).json({error:'Non autorisé'});next();}
app.get('/',(_,r)=>r.send('YUKI-MD is running 👑')); app.get('/health',(_,r)=>r.json({status:'ok'}));
app.get('/api/status',auth,(_,r)=>r.json({bot:'YUKI-MD',connected,uptimeSeconds:Math.floor(process.uptime())}));
app.get('/api/messages',auth,(_,r)=>r.json({messages:messages.slice(-50)}));
app.post('/api/send',auth,async(req,res)=>{try{const text=String(req.body?.text||'').trim();if(!text||text.length>3000)return res.status(400).json({error:'Message vide ou trop long.'});if(!OWNER)return res.status(503).json({error:'OWNER_NUMBER non configuré.'});if(!sock||!connected)return res.status(503).json({error:'Bot WhatsApp hors ligne.'});await sock.sendMessage(OWNER+'@s.whatsapp.net',{text});messages.push({direction:'out',text,time:new Date().toISOString()});while(messages.length>50)messages.shift();res.json({ok:true});}catch(e){res.status(500).json({error:'Échec envoi WhatsApp.'});}});
app.listen(PORT,()=>console.log('YUKI-MD API sur '+PORT));
async function start(){fs.mkdirSync(AUTH,{recursive:true});const {state,saveCreds}=await useMultiFileAuthState(AUTH);let version;try{({version}=await fetchLatestBaileysVersion());}catch{}
sock=makeWASocket({version,auth:state,logger:pino({level:'warn'}),browser:['YUKI-MD','Chrome','1.1.0'],syncFullHistory:false});
sock.ev.on('creds.update',saveCreds);
sock.ev.on('connection.update',({connection,lastDisconnect,qr:code})=>{if(code){console.log('Scanne le QR avec WhatsApp > Appareils connectés');qr.generate(code,{small:true});}if(connection==='open'){connected=true;console.log('YUKI-MD connecté 👑');}if(connection==='close'){connected=false;const status=lastDisconnect?.error?.output?.statusCode;if(status!==DisconnectReason.loggedOut)setTimeout(()=>start().catch(console.error),5000);else console.error('Session déconnectée : refaire association.');}});
sock.ev.on('messages.upsert',async({messages:items,type})=>{if(type!=='notify')return;for(const m of items){try{if(!m.message||m.key.fromMe)continue;const jid=m.key.remoteJid;if(!jid||jid==='status@broadcast')continue;const sender=jid.split('@')[0].split(':')[0];const body=m.message.conversation||m.message.extendedTextMessage?.text||m.message.imageMessage?.caption||'';if(OWNER&&sender===OWNER){messages.push({direction:'in',text:body||'[Message non textuel]',time:new Date().toISOString()});while(messages.length>50)messages.shift();}
const text=String(body).trim();if(!text.startsWith('.'))continue;const [c,...args]=text.slice(1).split(/\s+/),cmd=c.toLowerCase(),group=jid.endsWith('@g.us');
if(['menu','help'].includes(cmd))await sock.sendMessage(jid,{text:'╭━━〔 👑 𝐘𝐔𝐊𝐈-𝐌𝐃 〕━━╮\n┃ .menu .ping .alive .info .owner\n┃ .joke .fact .groupinfo .tagall\n╰━━━━━━━━━━━━━━━━━━╯\n❤ 👑 🪬 🎉 🌹'},{quoted:m});
else if(cmd==='ping')await sock.sendMessage(jid,{text:'🏓 Pong ! YUKI-MD répond.'},{quoted:m});
else if(cmd==='alive')await sock.sendMessage(jid,{text:'👑 YUKI-MD est en ligne.'},{quoted:m});
else if(cmd==='info')await sock.sendMessage(jid,{text:'YUKI-MD V1.1 | Node.js | Render'},{quoted:m});
else if(cmd==='owner')await sock.sendMessage(jid,{text:OWNER?'👑 https://wa.me/'+OWNER:'Configure OWNER_NUMBER.'},{quoted:m});
else if(cmd==='joke')await sock.sendMessage(jid,{text:'Pourquoi le bot ne dort jamais ? Il reste toujours en ligne ! 😂'},{quoted:m});
else if(cmd==='fact')await sock.sendMessage(jid,{text:'🧠 Les pieuvres ont trois cœurs.'},{quoted:m});
else if(cmd==='groupinfo'&&group){const md=await sock.groupMetadata(jid);await sock.sendMessage(jid,{text:`👥 ${md.subject}\nMembres : ${md.participants.length}`},{quoted:m});}
else if(cmd==='tagall'&&group){const md=await sock.groupMetadata(jid),mentions=md.participants.map(p=>p.id);await sock.sendMessage(jid,{text:(args.join(' ')||'📢 Attention !')+'\n'+mentions.map(x=>'@'+x.split('@')[0]).join(' '),mentions},{quoted:m});}
}catch(e){console.error('Message error',e.message);}}});
}
start().catch(e=>{console.error(e);process.exit(1)}); process.on('SIGTERM',()=>process.exit(0));
